1. Evann Nalewajek
2. Gaëlle Leroux
