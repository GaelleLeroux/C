# Bibliothèques
* <stdio.h>
* <stdlib.h>
* <sys/types.h>
* <sys/stat.h>
* <fcntl.h>
* <unistd.h>
* <string.h>
* <time.h>

# Références
* groupe D
* https://github.com/johnsamuelwrites/jscourses/tree/master/c/2022

# Difficulté
* Moyen

# Commentaires
* TP très intéressant car il introduit beaucoup de nouvelles fonctions très utiles.

