

int add(int,int);

int sous(int,int);

int mul(int,int);

float divi(int,int);

int reste(int,int);

int et(int,int);

int ou(int,int);

unsigned int nega(unsigned int);