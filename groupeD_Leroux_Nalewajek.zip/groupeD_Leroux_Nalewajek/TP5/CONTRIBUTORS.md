1. Gaelle Leroux
2. Evann Nalewajek

