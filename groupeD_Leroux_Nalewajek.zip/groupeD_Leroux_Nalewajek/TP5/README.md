# Bibliothèques
* sys/types.h
* dirent.h
* unistd.h
* stdlib.h
* stdio.h
* string.h
* sys/socket.h
* sys/epoll.h
* netinet/in.h

# Références
* groupe D
* https://github.com/johnsamuelwrites/jscourses/tree/master/c/2022

# Difficulté
* Difficile

# Commentaires
* 
* 



