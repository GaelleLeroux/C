# Bibliothèques
* <string.h>
* <stdio.h>
* <stdlib.h>
* <unistd.h>
* <sys/types.h>
* <sys/socket.h>
* <netinet/in.h>

# Références
* groupe D
* https://github.com/johnsamuelwrites/jscourses/tree/master/c/2022

# Difficulté
* Difficile

# Commentaires
* La difficulté résidait dans l'utilisation de fonctions plus complexe, il a fallu
* plusieurs l'intervention d'un encadrant pour les comprendre.

